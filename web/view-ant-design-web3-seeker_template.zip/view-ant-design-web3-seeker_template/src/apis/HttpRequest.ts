import axios, {AxiosHeaders, AxiosInstance, AxiosRequestConfig, AxiosResponse} from 'axios';

interface RequestOptions extends AxiosRequestConfig {
    url: string; // 每次请求动态传入 URL
}


class HttpRequest {
    private readonly instance: AxiosInstance;
    private readonly retryErrorCodes: number[];

    constructor(timeout = 600000, maxRetries = 100, retryDelay = 2000, http_error_code: number[] = [502, 504, 429]) {

        // 将传入的 http_error_code 存储为实例属性
        this.retryErrorCodes = http_error_code;

        // 包装 axios 实例
        this.instance = axios.create({
            timeout,
            withCredentials: true, // 启用跨域 Cookie 支持
        });

        // 响应拦截器
        this.instance.interceptors.response.use(
            (response: AxiosResponse) => response, // 直接返回 data
            async (error) => {
                const {config, response} = error;


                // 302 状态码直接放行，不进行重试
                // console.log(response)
                // console.log(error)
                if (response?.status === 302) {
                    return Promise.resolve(response);
                }


                // 自动重试逻辑
                // 502 网站挂了
                // 504 请求超时
                // 429 连接过多
                // 获取允许重试的错误码数组，默认为 [502, 504, 429]
                const retryErrorCodes = this.retryErrorCodes;
                // 检查是否有响应对象（即 HTTP 状态码）
                if (error.response) {
                    // 自动重试逻辑
                    // 根据动态配置的错误码进行重试
                    if (retryErrorCodes.includes(response.status)) {
                        console.error('请求错误：状态码', error.response.status);
                        config.__retryCount = config.__retryCount || 0;

                        // 如果重试次数未超过最大值
                        if (config.__retryCount < maxRetries) {
                            config.__retryCount += 1;
                            console.log(`重试第 ${config.__retryCount} 次，状态码: ${response.status}`);

                            // 等待一段时间后重试
                            await this.delay(retryDelay);
                            return this.instance(config); // 重新发起请求
                        }
                    } else {
                        // 如果响应的状态码不是需要重试的错误码，直接输出日志
                        console.error('请求错误：', {
                            status: error.response.status, // 获取响应状态码
                            data: error.response.data,     // 错误响应数据
                        });
                    }

                } else if (error.request) {
                    // 如果没有收到响应，打印请求信息
                    console.error('请求未收到响应：', error.request);
                } else {
                    // 如果是请求配置错误，输出错误消息
                    console.error('请求配置错误：', error.message);
                }

                // 将错误继续向上传递
                return Promise.reject(error.response?.data || error.message);
            }
        );

    }

// 工具方法：延迟
    private delay(ms: number) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    // 通用请求方法
    public async request<T = any>(options: RequestOptions): Promise<AxiosResponse<T>> {
        // options.httpAgent = agent; // 配置代理
        // options.httpsAgent = agent; // 配置代理
        return await this.instance.request<T>(options); // 返回已处理的 data
    }

    // GET 方法
    public async get<T = any>(url: string, params?: Record<string, any>, headers?: AxiosHeaders, maxRedirects?: number): Promise<AxiosResponse<T>> {
        return this.request<T>({
            method: 'GET',
            url,
            params,
            headers,
            maxRedirects: maxRedirects,
        });
    }


    // POST 方法
    public async post<T = any>(url: string, data?: Record<string, any>, headers?: AxiosHeaders): Promise<AxiosResponse<T>> {
        return this.request<T>({
            method: 'POST',
            url,
            data,
            headers,
        });
    }
}

export default HttpRequest;