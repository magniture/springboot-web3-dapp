import HttpRequest from "./HttpRequest";


export class DoHttp {
    private client: HttpRequest;
    private headers: any;

    public static instance: DoHttp;

    private constructor(client?: HttpRequest, headers?: any) {
        console.log('客户端被创建...')
        this.client = client || new HttpRequest(); // 默认使用一个新的 HttpRequest 实例
        this.headers = headers;
    }

    // 单例模式加载实例
    public static load(client?: HttpRequest, headers?: any): DoHttp {
        if (!DoHttp.instance) {
            DoHttp.instance = new DoHttp(client, headers); // 如果实例不存在，则创建新的实例
        }
        return DoHttp.instance;
    }


    public setHeaders = async (headers: any) => {
        this.headers = headers;
    }

    public getUrl = (path: string) => {
        return "/api" + path;
    }

    public doIndex = async () => {
        return await this.client.get(this.getUrl('/'));
    }

    public doProductList = async (data?: any) => {
        return await this.client.get(this.getUrl('/product/list'), data);
    }
    public doProductDetail= async (data?: any) => {
        return await this.client.get(this.getUrl('/product/detail'), data);
    }
}