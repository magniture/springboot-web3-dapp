import React, {ReactNode, useContext} from 'react';
import {DoHttp} from "./api";

// 创建上下文
export const DoHttpContext = React.createContext<DoHttp | undefined>(undefined);

// 提供者组件
interface DoHttpProviderProps {
    children: ReactNode;
}

export const DoHttpProvider = ({children}: DoHttpProviderProps) => {
    return (
        <DoHttpContext.Provider value={DoHttp.load()}>
            {children}
        </DoHttpContext.Provider>
    );
};

// 自定义Hook
export const useHttpApi = (): DoHttp => {
    const context = useContext(DoHttpContext);
    if (!context) {
        throw new Error(
            '请在使用useDoHttp的组件树外层包裹<DoHttpProvider>组件\n' +
            '正确用法示例：\n' +
            'const App = () => (\n' +
            '  <DoHttpProvider>\n' +
            '    <YourComponent />\n' +
            '  </DoHttpProvider>\n' +
            ')'
        );
    }
    return context;
};