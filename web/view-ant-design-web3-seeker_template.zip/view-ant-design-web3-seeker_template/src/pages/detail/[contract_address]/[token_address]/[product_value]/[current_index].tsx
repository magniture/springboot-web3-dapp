import React, {Fragment, useEffect, useState} from 'react';
import {useRouter} from "next/router";
import {
    Breadcrumb, Card,
    Descriptions,
    DescriptionsProps,
    Divider,
    Layout,
    Progress,
    Spin, Table, TableProps,
    Tabs,
    TabsProps,
    Typography
} from "antd";
import {useHttpApi} from "@/apis/DoHttpContext";
import ProductGridMini from "@/components/product/mini/ProductGridMini";
import ProductCardMini from "@/components/product/mini/ProductCardMini";
import {Product} from "@/utils/tool";
import ModalJoin from "@/components/ModalJoin";
import MyProductDescription from "@/components/product/description";
import {formatTimestamp} from "@/utils/MyTime";

//
const contentStyle: React.CSSProperties = {
    // textAlign: 'center',
    // minHeight: 120,
    // lineHeight: '120px',
    // color: '#fff',
    // backgroundColor: '#0958d9',
};

const siderStyle: React.CSSProperties = {
    // textAlign: 'center',
    // lineHeight: '120px',
    // color: '#fff',
    backgroundColor: '#eee',
};


const color: React.CSSProperties = {
    // textAlign: 'center',
    // lineHeight: '120px',
    color: '#fff',
    // backgroundColor: '#eee',
};

const Detail = () => {
    let router = useRouter();
    let {contract_address, product_value, token_address, current_index} = router.query;


    const [recording, setRecording] = useState<any>([])

    const [item, setItem] = useState<any>();


    let http = useHttpApi();
    const loadData = () => {
        // 读取产品详情
        http.doProductDetail({contract_address, product_value, token_address, current_index}).then(res => {
            // console.log('doProductDetail', res.data)
            setItem(res.data.data);
        })

        // 读取往期产品列表
        http.doProductList({state: 30}).then(res => {
            setRecording(res.data.data)
        })
    }
    useEffect(() => {
        if (contract_address && product_value && token_address && current_index) {
            loadData();
        }
    }, [contract_address, product_value, token_address, current_index]);

    if (!item) {
        return <Spin/>
    }
    const loadHead = () => {
        //10; 参与中，  20；等待开奖 。， 30；已经开奖
        let number = Product.formatState(item);
        if (number == 30) {
            return <div className="flex justify-between mt-10 mb-10">
                <div className="flex justify-between items-center">
                    <Typography.Title>{Product.formatAmountString(item)}</Typography.Title>
                </div>

                <div className="flex justify-between items-center gap-10">
                    <div className="flex items-baseline gap-2">
                        <span className="text-sm text-gray-600">中奖号码</span>
                        <span
                            className="text-base font-bold text-orange-500">{Product.formatWinningCode(item)}</span>
                    </div>
                    <div className="flex items-baseline gap-2">
                        <span className="text-sm text-gray-600">中奖地址</span>
                        <span
                            className="text-base font-bold text-orange-500">{Product.formatWinningAddress(item)}</span>
                    </div>
                </div>
            </div>
        }

        if (number == 20) {
            return <div className="flex justify-between mt-10 mb-10">
                <div className="flex justify-between items-center">
                    <Typography.Title>{Product.formatAmountString(item)}</Typography.Title>
                </div>

                <div className="flex justify-between items-center gap-10">
                    <div className="flex items-baseline gap-2">
                        <span
                            className="text-base font-bold text-orange-500">已完成，等待区块确认后开奖!</span>
                    </div>
                </div>
            </div>
        }

        return <div className="flex justify-between mt-10 mb-10">
            <div className="flex justify-between items-center">
                <Typography.Title>{Product.formatAmountString(item)}</Typography.Title>
            </div>

            <div className="flex justify-between items-center">
                <ModalJoin
                    item={item}
                    onOK={() => {
                        setTimeout(() => {
                            loadData();
                        }, 3000)
                    }}/>
            </div>
        </div>
    }

    const items: DescriptionsProps['items'] = [
        {
            key: '1',
            label: '令牌地址',
            children: <div>{Product.formatTokenAddress(item)}</div>,
            span: 2,
        },
        {
            key: '2',
            label: '令牌符号',
            children: <p>{Product.formatSymbol(item)}</p>,
        },
    ];

    const columns: TableProps<any>['columns'] = [
        {
            title: '用户地址',
            dataIndex: 'userAddress',
            key: 'userAddress',
            render: (text) => <p>{text}</p>,
        },
        {
            title: '幸运号码',
            dataIndex: 'lockCode',
            key: 'lockCode',
            render: (text) => <p>{text}</p>,
        },
        {
            title: '操作区块',
            dataIndex: 'blockNumber',
            key: 'blockNumber',
            render: (text) => <p>{text}</p>,
        },
    ];
    const tab_items: TabsProps['items'] = [
        {
            key: '1',
            label: '参与列表',
            children: <Table<any> columns={columns} dataSource={item.orders}/>,
        },
        {
            key: '2',
            label: '开奖规则',
            children: <MyProductDescription/>,
        },
    ];


    let state = Product.formatState(item);
    if (state == 30) {

        //1、 区块求和
        let total = 0n;
        for (let i = 0; i < item.blocks.length; i++) {
            let record = item.blocks[i];
            let number = BigInt(record.number);
            let transactionCount = BigInt(record.transactionCount);
            let timestamp = BigInt(record.timestamp);
            let a = number * transactionCount;
            a = a + timestamp;
            total = total + a;
        }

        //2、 商品份数求余数
        let yu = total % BigInt(Product.formatMaxCount(item));

        //3、 加上原始数据，就是开始号码
        let lock_code = yu + BigInt(Product.formatStartLockCode(item));

        tab_items.push({
            key: '3',
            label: '开奖细节',
            children: <Fragment>
                <Card>
                    <div className={'flex gap-5'}>
                        <div>step1:</div>
                        <div>表格求和</div>
                        <div style={{color: 'green'}}> {String(total)}</div>
                    </div>
                    <div className={'flex gap-5'}>
                        <div>step2:</div>
                        <div>商品求与</div>
                        <div>{String(total)}</div>
                        <div>%</div>
                        <div>{String(Product.formatMaxCount(item))}</div>
                        <div>=</div>
                        <div style={{color: 'green'}}> {String(yu)}</div>
                    </div>
                    <div className={'flex gap-5'}>
                        <div>step3:</div>
                        <div>开奖号码</div>
                        <div>{String(yu)}</div>
                        <div>+</div>
                        <div>{String(Product.formatStartLockCode(item))}</div>
                        <div>=</div>
                        <div style={{color: 'green'}}> {String(lock_code)}</div>
                    </div>
                </Card>
                <Table<any>
                    pagination={false}
                    columns={[
                        {
                            title: "区块号码",
                            key: 'number',
                            dataIndex: "number"
                        },
                        {
                            title: "交易次数",
                            key: 'transactionCount',
                            dataIndex: "transactionCount"
                        },
                        {
                            title: "区块时间",
                            key: 'timestamp',
                            dataIndex: "timestamp",
                            render: value => {
                                return <div className={'flex gap-2'}>
                                    <div>{formatTimestamp(value)}</div>
                                    <div>-></div>
                                    <div style={{color: 'green'}}>{value}</div>
                                </div>
                            }
                        },
                        {
                            title: "区块随机数",
                            key: 'index',
                            dataIndex: "index",
                            render: (value, record) => {

                                let number = BigInt(record.number);
                                let transactionCount = BigInt(record.transactionCount);
                                let timestamp = BigInt(record.timestamp);

                                let a = number * transactionCount;
                                a = a + timestamp;
                                return <div className={'flex gap-2'}>
                                    <div>(</div>
                                    <div>{record.number}</div>
                                    <div>*</div>
                                    <div>{record.transactionCount}</div>
                                    <div>)</div>
                                    <div>+</div>
                                    <div>{record.timestamp}</div>
                                    <div>=</div>
                                    <div style={{color: 'green'}}>{String(a)}</div>
                                </div>
                            }
                        },
                    ]} dataSource={item.blocks}/>
            </Fragment>,
        })
    }


    return <Layout>
        <Layout.Content style={contentStyle}>
            <div className={'m-5'}>
                <Breadcrumb
                    // className={"cursor-pointer m-5"}
                    items={[
                        {
                            title: 'Home',
                            className: "cursor-pointer",
                            onClick: () => {
                                router.push("/")
                            }
                        },
                        {
                            title: current_index,
                        }
                    ]}
                />

                {loadHead()}
                {/* 进度条 */}
                <Progress
                    percent={Product.formatJoinProgress(item)}
                    strokeColor="#00b578"
                    strokeWidth={24}
                    showInfo={true}
                    rootClassName={'color'}
                    className="w-full"
                    percentPosition={{align: 'center', type: 'inner'}}
                />

                {/* 参与进度描述 */}
                <div className="flex justify-between mt-2">
                    <div className="flex justify-between items-center">
                        <div className="flex items-baseline gap-2">
                            <span className="text-sm text-gray-600">总需</span>
                            <span className="text-base font-bold text-orange-500">{Product.formatMaxCount(item)}</span>
                            <span className="text-sm text-gray-600">次</span>
                        </div>
                    </div>

                    <div className="flex justify-between items-center">
                        <div className="flex items-baseline gap-2">
                            <span className="text-sm text-gray-600">剩余</span>
                            <span className="text-base font-bold text-orange-500">{Product.formatUseCount(item)}</span>
                            <span className="text-sm text-gray-600">次</span>
                        </div>
                    </div>
                </div>

                <Divider/>

                {/* 辅助显示*/}
                <Descriptions items={items} className={'mt-5'}/>

                <Tabs defaultActiveKey="1" items={tab_items} className={'mt-5'}/>
            </div>

        </Layout.Content>
        <Layout.Sider width="25%" style={siderStyle}>
            <ProductGridMini>

                {
                    recording.map(value => {
                        return <ProductCardMini
                            key={Product.formatProductKey(value)}

                            product_id={Product.formatProductId(value)}

                            current_index={Product.formatCurrentIndex(value)}

                            amount_string={Product.formatAmountString(value)}
                            join_progress={Product.formatJoinProgress(value)}
                            use_count={Product.formatUseCount(value)}

                            url={Product.formatDetailUrl(value)}

                            winning_code={Product.formatWinningCode(value)}
                            winning_address={Product.formatWinningAddress(value)}
                            winning_block_number={Product.formatWinningBlockNumber(value)}
                        />

                    })
                }
            </ProductGridMini>
        </Layout.Sider>
    </Layout>
};

export default Detail;
