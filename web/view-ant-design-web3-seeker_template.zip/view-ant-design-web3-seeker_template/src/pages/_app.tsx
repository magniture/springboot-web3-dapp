import '@/styles/globals.css'
import type {AppProps} from 'next/app'
import React from "react";
import {Layout} from "antd";
import {useRouter} from "next/router";
import {EthersWeb3ConfigProvider, MetaMask, OkxWallet} from "@ant-design/web3-ethers";
import {ConnectButton, Connector} from "@ant-design/web3";
import {Localhost, Mainnet} from "@ant-design/web3-wagmi";
import {DoHttpProvider} from "@/apis/DoHttpContext";
import {bscTestnet} from "viem/chains";

const {Header, Content} = Layout;

const layoutStyle: React.CSSProperties = {
    borderRadius: 8,
    overflow: 'hidden',
};
const headerStyle: React.CSSProperties = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    textAlign: 'center',
    color: '#fff',
    height: 64,
    paddingInline: 48,
    lineHeight: '64px',
    backgroundColor: '#151a13',
    fontSize: 18
};
export default function App({Component, pageProps}: AppProps) {
    let router = useRouter();

    const loadView = () => {
        return <EthersWeb3ConfigProvider
            // walletConnect={{ projectId: YOUR_WALLET_CONNECT_PROJECT_ID }}
            balance={true}
            chains={[Mainnet, Localhost,bscTestnet]}
            wallets={[MetaMask(), OkxWallet()]}
        >
            <DoHttpProvider>
                <main className={`flex items-center justify-between p-24`}>
                    <Layout style={layoutStyle}>
                        <Header style={headerStyle} className={'cursor-pointer'}>
                            <div onClick={async () => {
                                await router.push('/')
                            }}>智能合约app开发
                            </div>

                            <Connector>
                                <ConnectButton/>
                            </Connector>
                        </Header>
                        <Component {...pageProps} />
                    </Layout>
                </main>
            </DoHttpProvider>
        </EthersWeb3ConfigProvider>
    }
    return loadView();
}
