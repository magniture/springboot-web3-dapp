import React, {useEffect, useState} from "react";
import {Layout} from "antd";
import {useAccount} from "@ant-design/web3";
import {useHttpApi} from "@/apis/DoHttpContext";
import ProductGrid from "@/components/product/card/ProductGrid";
import ProductCard from "@/components/product/card/ProductCard";
import {Product} from "@/utils/tool";
import ModalJoin from "@/components/ModalJoin";

const Home = () => {
    let http = useHttpApi();

    const [list, setList] = useState<any>([])


    const loadProductList = () => {
        http.doProductList().then(res => {
            let data = res.data.data;
            setList(data);
        });
    }


    useEffect(() => {
        loadProductList();
    }, []);

    return <Layout.Content>

        <ProductGrid>
            {list.map(value => {
                return <ProductCard

                    key={Product.formatProductKey(value)}

                    product_id={Product.formatProductId(value)}

                    current_index={Product.formatCurrentIndex(value)}

                    amount_string={Product.formatAmountString(value)}
                    join_progress={Product.formatJoinProgress(value)}
                    use_count={Product.formatUseCount(value)}

                    url={Product.formatDetailUrl(value)}
                    button={<ModalJoin
                        item={value}
                        onOK={() => {
                            setTimeout(() => {
                                loadProductList();
                            }, 3000)
                        }}/>}
                />
            })}
        </ProductGrid>

    </Layout.Content>
};

export default Home;


