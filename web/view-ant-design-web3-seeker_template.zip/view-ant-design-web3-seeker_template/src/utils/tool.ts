import {ethers} from "ethers";

export class Product {

    static formatProductId = (item: any) => {
        return item?.id;
    }

    static formatProductKey = (item: any) => {
        return item?.id;
    }
    static formatProductValue = (item: any) => {
        return item?.productValue;
    }

    static formatTokenAddress = (item: any) => {
        return item?.tokenAddress;
    }
    static formatContractAddress = (item: any) => {
        return item?.contractAddress;
    }
    static formatCurrentIndex = (item: any) => {
        return item?.currentIndex;
    }

    static formatAmountString = (item: any) => {

        // 币种符号
        let symbol = item.symbol.symbol;
        let decimals = item.symbol.decimals;

        let productValue = BigInt(item.productValue);


        return ethers.formatUnits(productValue, decimals) + ' ' + symbol;
    }

    static formatSymbol = (item: any) => {
        // 币种符号
        return item.symbol.symbol;
    }
    static formatDecimals = (item: any) => {
        // 币种符号
        return item.symbol.decimals;
    }
    static formatTicketValueAmountString = (item: any) => {

        // 币种符号
        let symbol = item.symbol.symbol;
        let decimals = item.symbol.decimals;

        let productValue = BigInt(item.product.ticketValue);


        return ethers.formatUnits(productValue, decimals) + ' ' + symbol;
    }
    static formatTicketValue = (item: any) => {
        return BigInt(item.product.ticketValue);
    }
    static formatJoinProgress = (item: any) => {
        let maxCount = item.product.maxCount;
        let current = item.orders.length;

        let s = ((current / maxCount) * 100).toFixed(2);
        return Number(s);
    }

    static formatUseCount = (item: any) => {
        let maxCount = item.product.maxCount;
        let current = item.orders.length;
        return Number(maxCount) - Number(current);
    }
    static formatMaxCount = (item: any) => {
        return Number(item.product.maxCount);
    }

    static formatButtonName = (item: any) => {

        // 币种符号
        let symbol = item.symbol.symbol;
        let decimals = item.symbol.decimals;

        let productValue = BigInt(item.product.ticketValue);


        return ethers.formatUnits(productValue, decimals) + ' ' + symbol + ' 立即购买';
    }

    static formatDetailUrl = (item: any) => {
        let contractAddress = this.formatContractAddress(item);
        let tokenAddress = this.formatTokenAddress(item);
        let productValue = this.formatProductValue(item);
        let currentIndex = this.formatCurrentIndex(item);
        return '/detail/' + contractAddress + '/' + tokenAddress + '/' + productValue + "/" + currentIndex;
    }

    static formatWinningCode = (item: any) => {
        return item.winCode;
    }
    static formatWinningAddress = (item: any) => {
        return item.winAddress;
    }
    static formatWinningBlockNumber = (item: any) => {
        return item.winBlockNumber;
    }
    static formatState = (item: any) => {
        return Number(item.state);
    }
    static formatStartLockCode = (item: any) => {
        return BigInt(item.product.startLockCode);
    }
}