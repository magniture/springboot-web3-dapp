export function formatTimeAgo(date: Date): string {
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    // 使用 ASCII 字符定义时间单位，输出时映射到中文
    const units = [
        {limit: 31536000, suffix: '\u5e74'},    // 年 (Unicode 转义)
        {limit: 2592000, suffix: '个\u6708'},    // 月
        {limit: 86400, suffix: '\u5929'},    // 天
        {limit: 3600, suffix: '\u5c0f\u65f6'}, // 小时
        {limit: 60, suffix: '\u5206\u949f'}, // 分钟
    ];

    // 超过1年返回原始时间（ISO格式，可自定义）
    if (diffInSeconds >= units[0].limit) {
        return date.toISOString(); // 或自定义格式
    }

    for (const unit of units) {
        const interval = Math.floor(diffInSeconds / unit.limit);
        if (interval >= 1) {
            return `${interval}${unit.suffix}\u524d`; // 后缀加 "前"
        }
    }

    return '\u521a\u521a'; // "刚刚"
}


/**
 * 将 10 位时间戳（秒级）转换为 Date 对象
 * @param timestamp 10 位秒级时间戳
 * @returns Date 对象
 */
function timestampToDate(timestamp: number): Date {
    // 10 位时间戳是秒级，需乘以 1000 转为毫秒
    return new Date(timestamp * 1000);
}

/**
 * 将 Date 对象格式化为 ISO 字符串（UTC 时间）
 * @example "2023-10-01T12:00:00.000Z"
 */
function formatToISO(date: Date): string {
    return date.toISOString();
}

/**
 * 将 Date 对象格式化为中文本地时间字符串
 * @example "2023年10月1日 12:00:00"
 */
function formatToChineseLocal(date: Date): string {
    return date.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    }).replace(/\//g, '年')
        .replace(/(\d+年\d+)月/, '$1月')
        .replace('日', '日 ');
}

/**
 * 自定义格式化（如 "YYYY-MM-DD HH:mm:ss"）
 */
function formatCustom(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}


export function formatTimestamp(timestamp: number): string {
    // 10 位时间戳是秒级，需乘以 1000 转为毫秒
    let date = new Date(timestamp * 1000);
    return formatCustom(date);
}