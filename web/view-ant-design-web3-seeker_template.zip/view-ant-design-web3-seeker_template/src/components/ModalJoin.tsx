import React, {Fragment, useState} from 'react';
import {Button, InputNumber, message, Modal} from "antd";
import {Product} from "@/utils/tool";
import {ethers} from "ethers";
import {useEthersSigner} from "@ant-design/web3-ethers";
import {injected, useChainId, useConnect, useSwitchChain} from "wagmi";
import {loadErc20, loadMainContract} from "@/components/MyContract";

interface ModalJoinProps {
    item?: any;
    onOK: () => void
}

const ModalJoin: React.FC<ModalJoinProps> = ({item, onOK}) => {

    const [open, setOpen] = useState<boolean>(false);
    const [count, setCount] = useState<number>(1);
    const {connect} = useConnect()

    let signer = useEthersSigner();
    const chainId = useChainId()
    const {chains, switchChain} = useSwitchChain()

    // console.log(chainId)


    const tips = () => {
        if (!count || count == 0) {
            return <div></div>
        }
        let bigint = Product.formatTicketValue(item);

        let amount = bigint * BigInt(count);

        // alert(amount)
        let symbol = Product.formatSymbol(item);
        let decimals = Product.formatDecimals(item);
        let amount_str = ethers.formatUnits(amount, decimals) + ' ' + symbol;


        // 中奖了
        //let s =
        let number = count / Product.formatMaxCount(item);
        let string = (number * 100).toFixed(2);
        return <div className="flex justify-between items-center mt-2 ">
            <div className="flex items-baseline gap-2">
                <span className="text-sm text-gray-600">参与</span>
                <span className="text-base font-bold text-orange-500">{count}</span>
                <span className="text-sm text-gray-600">次, 预计成本</span>
                <span className="text-base font-bold text-orange-500">{amount_str}</span>
                <span className="text-sm text-gray-600">, 中奖率</span>
                <span className="text-base font-bold text-orange-500">{string} %</span>
            </div>

        </div>
    }
    return <Fragment>
        <Button type="primary" onClick={() => {

            if (!signer) {
                // 没有链接钱包
                // alert('没有链接钱包')
                connect({connector: injected()});
            } else {
                setOpen(true)
            }

        }} className={'w-full'}>
            {Product.formatButtonName(item)}
        </Button>
        <Modal
            title="请输入您要参与的次数"
            centered
            open={open}
            onOk={async () => {

                // 1、检查网络
                if (chainId != 97) {
                    //调用钱包切换网络
                    switchChain({chainId: 97})
                    return;
                }


                // 2、检查资金授权
                let erc20 = loadErc20(Product.formatTokenAddress(item), signer);

                // 待支付金额
                let bigint = Product.formatTicketValue(item);
                let amount = bigint * BigInt(count);
                console.log('待支付金额 ', amount);

                // 获取已授权资金
                //@ts-ignore
                let allowance = await erc20.allowance(signer.address, Product.formatContractAddress(item));
                console.log('已授权资金 ', allowance);

                if (allowance < amount) {
                    // 调用资金授权
                    try {
                        //@ts-ignore
                        await erc20.approve(Product.formatContractAddress(item), amount);
                        console.log('授权成功')
                    } catch (e) {
                        console.error(e);
                        message.error('资金授权失败')
                        return;
                    }
                }


                // 3、调用合约参与方法
                let mainContract = loadMainContract(Product.formatContractAddress(item), signer);


                try {

                    // console.log(Product.formatTokenAddress(item))
                    // console.log(Product.formatProductValue(item))
                    // console.log(count)


                    //@ts-ignore

                    await mainContract.confirmJoin(Product.formatTokenAddress(item), BigInt(Product.formatProductValue(item)), BigInt(count));
                    message.success('参加成功~');
                    setOpen(false);


                    onOK && onOK();

                } catch (e) {
                    console.error(e);
                    message.error('参加失败')
                    return;
                }
            }}
            onCancel={() => setOpen(false)}
        >
            <div
                className={'mt-6 mb-2'}
                style={{
                    fontSize: 13,
                    textAlign: 'right',
                    color: '#999'
                }}
            >单次价值: {Product.formatTicketValueAmountString(item)}</div>

            <InputNumber
                className={'w-full'}
                min={1}
                addonAfter={"次"}
                max={Product.formatUseCount(item)}
                defaultValue={count}
                onChange={value => {
                    setCount(value as number);
                }}/>

            {tips()}
        </Modal>
    </Fragment>

};

export default ModalJoin;
