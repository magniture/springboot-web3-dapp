import React, {ReactNode} from 'react';
import {Typography} from "antd";

const ProductGridMini = ({children}: { children: ReactNode }) => {
    return <div>

        <Typography.Title level={3} className={'px-4'} style={{marginTop: 10}}>往期项目</Typography.Title>
        <div
            className="flex flex-wrap gap-4 sm:px-4 md:px-4 py-4 max-w-screen-2xl mx-auto w-full">
            {children}
        </div>
    </div>
};

export default ProductGridMini;