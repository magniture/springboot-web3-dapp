import React from 'react';
import {Divider, Typography} from "antd";

const {Title, Paragraph, Text, Link} = Typography;

const MyProductDescription = () => {
    return <Typography className={'p-5'}>

        <Title level={3}>号码发放规则</Title>
        <br/>
        <Typography.Text>1、起始值：每期幸运号码从 10000001 开始分配, 结束值：为起始值 +
            商品份数；</Typography.Text>
        <br/>
        <br/>
        <Typography.Text>2、递增规则：参与者，每参与一次，则按顺序分配一个幸运码，依次递增, 比如：10000001,
            10000002,10000003....
        </Typography.Text>
        <blockquote>
            单笔交易参与多次，将分配多个幸运号码，是按商品份数分配，不是交易次数，即参与次数越多，中奖记录越大。
        </blockquote>
        <br/>
        <Typography.Text>3、唯一性：每个幸运号码在当前期数内唯一，不会重复，且智能合约自动分配幸运号码，链上可查可验；</Typography.Text>

        <Divider/>
        <Title level={3}>计算规则</Title>
        <br/>
        <Typography.Text>1、停单区块：商品的最后一个号码分配完毕后，将公示该交易的，区块号码，也称区块高度；</Typography.Text>
        <br/>
        <br/>
        <Typography.Text>
            2、开奖区块：停单区块开始（不包含停单区块本身） + 20个区块后开始执行开奖，即最少20次确认后才会执行开奖
        </Typography.Text>
        <blockquote>
            <div> 比如停单区块号码: 1625</div>
            <br/>
            <div>逻辑计算区块为， 1626, 1627, 1628 .....1643, 1644, 1645</div>
            <br/>
            <div>后续根据这20个区块数据，计算开奖</div>
        </blockquote>
        <br/>
        <Typography.Text>3、开奖规则：停单区块和开奖区块产生后，系统开始计算中奖幸运号码</Typography.Text>
        <br/>
        <br/>
        <Typography.Text> 4、中奖号码计算：
            <blockquote>
                <div>
                    第一步: 得到 停单区块 -> 开奖区块 这20个区块的详细信息
                </div>
                <br/>
                <div>
                    第二步: 得到每个区块的随机数： (得到区块的区块号码 * 区块的交易次数) + 区块时间戳
                </div>
                <br/>
                <div>
                    第三步: 得到幸运号码： (把所有区块随机数加起来 % 商品份数) + 幸运号码起始值即10000001
                </div>
                <br/>
                <div>
                    至此幸运号码产生，所有数据，所有计算过程，链上可查可验。
                </div>
            </blockquote>
        </Typography.Text>
        <Typography.Text>5、奖品发放：中奖幸运号码产生后，系统依次打款，您无需干预，也无需领取，系统自动打款。</Typography.Text>
        <br/>
        <br/>
        <Divider/>
        <Title level={3}>安全机制</Title>
        <br/>
        <Typography.Text>随机性保障 - 依赖未来区块数据确保无法预测结果</Typography.Text>
        <br/>
    </Typography>
};

export default MyProductDescription;
