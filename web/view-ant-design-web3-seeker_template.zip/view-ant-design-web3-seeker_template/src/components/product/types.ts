import React from "react";

export interface ProductCardProps {
    key: string; // 唯一键
    product_id: string; // 产品ID
    current_index: string; // 产品期号

    amount_string: string; // 产品金额

    join_progress: number; // 进度百分比
    use_count: number; // 可参与次数

    button?: React.ReactNode; // 参与按钮

    //***************************已开奖信息

    winning_code?: string; //开奖号码

    winning_address?: string; // 中奖地址

    winning_block_number?: number;// 开奖号码


    //***************************url
    url?: string

}