import React, {ReactNode} from 'react';

const ProductGrid = ({children}: { children: ReactNode }) => {
    return (
        <div
            className="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6 px-4 sm:px-6 md:px-8 py-8 max-w-screen-2xl mx-auto w-full">
            {children}
        </div>
    );
};

export default ProductGrid;