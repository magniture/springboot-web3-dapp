import {Carousel, Progress, Typography} from "antd";
import React from "react";
import {useRouter} from "next/router";
import {ProductCardProps} from "@/components/product/types";


const ProductCard = (item: ProductCardProps) => {

    let router = useRouter();
    const x = (time: string, address: string): React.ReactNode => {
        return (
            <div style={{display: 'flex', alignItems: 'center'}}>
                <div style={{display: 'flex', alignItems: 'center', gap: 5}}>
                    <div>{time}</div>
                    <Typography.Link>23sf...asfa</Typography.Link>
                    <div>获得该奖励!</div>
                </div>
            </div>
        );
    }

    return (
        <div
            key={item.key}
            className="relative flex flex-col w-full max-w-[320px] min-w-[280px] border-2 border-gray-100 rounded-2xl p-6 bg-white shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
            {/*<div className="absolute top-4 right-4 z-10">*/}
            {/*    <BlockchainIcon/>*/}
            {/*</div>*/}

            {/*/!* 彩带效果 *!/*/}
            {/*<div*/}
            {/*    className="absolute -top-2 -right-2 bg-green-500 text-white px-8 py-1 text-sm font-medium rotate-45 shadow-md">*/}
            {/*    2323撒发发撒师傅*/}
            {/*</div>*/}

            {/* Header */}
            <div
                className="text-sm font-medium text-gray-500 mb-4 tracking-wide truncate cursor-pointer hover:text-blue-500 hover:scale-105 transition-transform duration-200"
                onClick={() => {
                    console.log(item.url)
                    // let url = '/details/' + item.product_id + '/' + item.current_index;
                    router.push(item.url);
                }}
            >
                No: {item.current_index}
            </div>

            {/* Main Content */}
            <div className="flex flex-col flex-1 justify-between">
                {/* 金额区块 */}
                <div className="space-y-6">
                    <div className="flex justify-between items-end">
                        <h3 className="text-2xl font-bold text-gray-900 truncate">
                            {item.amount_string}
                        </h3>
                    </div>

                    {/* 进度条 */}
                    <Progress
                        percent={item.join_progress}
                        strokeColor="#00b578"
                        strokeWidth={12}
                        showInfo={true}
                        className="w-full"
                    />
                </div>

                {/* 操作区块 */}
                <div className="pt-2">
                    <div className="flex justify-between items-center">
                        <div className="flex items-baseline gap-2">
                            <span className="text-sm text-gray-600">剩余</span>
                            <span className="text-base font-bold text-orange-500">{item.use_count}</span>
                            <span className="text-sm text-gray-600">次</span>
                        </div>
                    </div>
                </div>
                <div className="pt-8 w-full">
                    {item.button}
                </div>
            </div>

            {/* Footer */}
            <div className="mt-6 pt-4 border-t-2 border-dashed border-gray-200 text-base text-gray-500 truncate">
                <Carousel autoplay dots={false}>
                    {x('13小时前', '3ea212..127c18')}
                    {x('32小时前', '322122..1212')}
                </Carousel>
            </div>

            {/* 全局样式覆盖 */}
            <style jsx global>{`
                /* 统一进度条高度 */
                .ant-progress-line {
                    width: 100% !important;
                }

                /* 保持按钮文字不换行 */
                button {
                    white-space: nowrap;
                }
            `}</style>
        </div>
    );
};

export default ProductCard;