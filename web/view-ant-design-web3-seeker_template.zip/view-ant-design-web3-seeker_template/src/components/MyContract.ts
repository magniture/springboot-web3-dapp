import {ethers} from "ethers";
import type {ContractRunner} from "ethers/lib.commonjs/providers";

export const loadErc20 = (address: string, signer: ContractRunner) => {
    const ERC20_ABI = [
        // 基础函数
        "function name() view returns (string)",
        "function symbol() view returns (string)",
        "function decimals() view returns (uint8)",
        "function totalSupply() view returns (uint256)",
        "function balanceOf(address account) view returns (uint256)",
        "function transfer(address recipient, uint256 amount) returns (bool)",
        "function allowance(address owner, address spender) view returns (uint256)",
        "function approve(address spender, uint256 amount) returns (bool)",
        "function transferFrom(address sender, address recipient, uint256 amount) returns (bool)",

        // 事件
        "event Transfer(address indexed from, address indexed to, uint256 value)",
        "event Approval(address indexed owner, address indexed spender, uint256 value)"
    ] as const;
    return new ethers.Contract(address, ERC20_ABI, signer);
}

export const loadMainContract = (address: string, signer: ContractRunner) => {

    let abi = [
        "function confirmJoin(address token_address, uint256 product_value, uint256 count)"
    ];

    return new ethers.Contract(address, abi, signer);
}