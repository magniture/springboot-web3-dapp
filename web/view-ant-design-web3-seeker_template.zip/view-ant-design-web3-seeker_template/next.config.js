/** @type {import('next').NextConfig} */
const nextConfig = {
    reactStrictMode: true,
    transpilePackages: [
        "@ant-design",
        "antd",
        "rc-util",
        "rc-tree", // 添加 rc-tree 确保其被 Babel 转译
        "rc-table", // 添加 rc-table
        "rc-pagination",
        "rc-picker",
        "rc-input",
    ],
    async rewrites() {
        return [
            {
                source: '/api/:path*',
                destination: 'http://127.0.0.1:7070/:path*',
            },
        ];
    },
};

module.exports = nextConfig;