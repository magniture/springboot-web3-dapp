import type {Config} from 'tailwindcss'
import {OptionalConfig, RequiredConfig} from "tailwindcss/types/config";

//@ts-ignore
const config: RequiredConfig & Partial<OptionalConfig> = {
    content: [
        './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
        './src/components/**/*.{js,ts,jsx,tsx,mdx}',
        './src/app/**/*.{js,ts,jsx,tsx,mdx}',
    ],
    theme: {
        extend: {
            backgroundImage: {
                'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
                'gradient-conic':
                    'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
            },
            borderStyle: {
                'dashed-gradient': 'repeating-linear-gradient(45deg, #d1d5db, #d1d5db 2px, transparent 2px, transparent 4px)'
            }
        },
    },
    plugins: []
}
export default config
